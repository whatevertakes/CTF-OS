from Crypto.Util.number import isPrime, getPrime, bytes_to_long, GCD
from tqdm import tqdm

for _ in tqdm(__import__("itertools").count()):
    p, q, r = getPrime(256), getPrime(256), getPrime(256)

    a = (p << 512) + (q << 256) + r
    b = (r << 512) + (q << 256) + p

    if not isPrime(a) or not isPrime(b):
        continue

    N = a * b
    e = 65537
    if GCD(e, a - 1) != 1 or GCD(e, b - 1) != 1:
        continue

    with open("flag", "rb") as f:
        flag = bytes_to_long(f.read())
    
    c = pow(flag, e, N)
    print(f"{N = }")
    print(f"{e = }")
    print(f"{c = }")
    break