#!/bin/bash

pkill simduino
cd /home/arduino
echo "Send your hex file in 2 seconds!"
timeout 2 cat > ./user.hex
echo "DONE! let's roll!"

timeout 60 ./simduino.elf ./user.hex
